/**
 * Démo « chaîne de mesure du LCR-mètre ».
 *
 * Une impulsion parcourt quatre étages (analogique, CAN, MCU, DSP) puis le résultat.
 * Le fil rouge est la phase entre V et I : chaque étage la montre sous sa forme du moment
 * (décalage temporel, échantillons datés, deux tableaux de nombres, angle entre phaseurs).
 * Les calculs viennent de dsp.ts (Web Worker) ; ce fichier ne fait que l'interface et le dessin.
 */
import { AMP, FS, N, type AcquireRequest, type AcquireResult, type Dut } from './dsp.ts';

interface Labels {
  impedance: string;
  phase: string;
  dut: Record<Dut, string>;
  value: Record<Dut, string>;
  rs: Record<'C' | 'L', string>;
  play: string;
  pause: string;
  carries: { analog: string; adc: string; adcMux: string; mcu: string; dsp: string; result: string };
}

type Painter = (s: number) => void;

const MINUS = '−';
const TAU = 2 * Math.PI;
/** Durée d'un cycle complet (quatre étages + résultat), en ms. */
const CYCLE_MS = 9500;
/** Part de chaque étage pendant laquelle il s'anime ; le reste sert au déplacement de l'impulsion. */
const DWELL = 0.82;
const PREFIXES: ReadonlyArray<readonly [number, string]> = [
  [1e-12, 'p'],
  [1e-9, 'n'],
  [1e-6, 'µ'],
  [1e-3, 'm'],
  [1, ''],
  [1e3, 'k'],
  [1e6, 'M'],
];

function must<T extends Element>(root: ParentNode, selector: string): T {
  const el = root.querySelector<T>(selector);
  if (!el) throw new Error(`bench: élément manquant ${selector}`);
  return el;
}

const clamp01 = (x: number): number => Math.min(Math.max(x, 0), 1);
const sliderToFreq = (x: number): number => 100 * 200 ** (x / 100);
const toDut = (v: string): Dut => (v === 'R' || v === 'L' ? v : 'C');
const unitOf = (d: Dut): string => (d === 'R' ? 'Ω' : d === 'C' ? 'F' : 'H');
const deg = (rad: number): number => (rad * 180) / Math.PI;
const wrap = (rad: number): number => Math.atan2(Math.sin(rad), Math.cos(rad));

function derive(dut: Dut, omega: number, re: number, im: number): { val: number; rs: number } {
  switch (dut) {
    case 'R':
      return { val: re, rs: re };
    case 'C':
      return { val: im < 0 ? -1 / (omega * im) : NaN, rs: re };
    case 'L':
      return { val: im / omega, rs: re };
  }
}

export function startBench(root: HTMLElement): void {
  const lang = document.documentElement.lang || 'en';
  const nf = (digits: number) => new Intl.NumberFormat(lang, { maximumSignificantDigits: digits });
  const num = (x: number, digits = 4): string => nf(digits).format(x).replace('-', MINUS);
  const eng = (x: number, unit: string, digits = 4): string => {
    if (!Number.isFinite(x)) return '–';
    if (Math.abs(x) < 1e-15) return `0 ${unit}`;
    const a = Math.abs(x);
    let pick = PREFIXES[0];
    for (const p of PREFIXES) if (a >= p[0] * 0.99995) pick = p;
    return `${num(x / pick[0], digits)} ${pick[1]}${unit}`;
  };
  const signed = (x: number, digits: number, unit: string): string =>
    Number.isFinite(x) ? `${x < 0 ? MINUS : '+'}${num(Math.abs(x), digits)}${unit}` : '–';
  const fmt = (template: string, vars: Record<string, string>): string =>
    template.replace(/\{(\w+)\}/g, (_, key: string) => vars[key] ?? '');

  const labels = JSON.parse(must<HTMLScriptElement>(root, 'script[data-bench-labels]').textContent ?? '{}') as Labels;

  // ---- éléments ----
  const dutSel = must<HTMLSelectElement>(root, 'select[name="dut"]');
  const freqEl = must<HTMLInputElement>(root, 'input[name="freq"]');
  const snrEl = must<HTMLInputElement>(root, 'input[name="snr"]');
  const playBtn = must<HTMLButtonElement>(root, 'button[data-play]');
  const replayBtn = must<HTMLButtonElement>(root, 'button[data-replay]');
  const rsRow = must<HTMLElement>(root, '[data-row="rs"]');
  const srEl = must<HTMLElement>(root, '[data-out="sr"]');
  const chain = must<HTMLElement>(root, '[data-chain]');
  const pulse = must<HTMLElement>(root, '[data-pulse]');
  const stageEls = (['analog', 'adc', 'mcu', 'dsp', 'result'] as const).map((k) =>
    must<HTMLElement>(root, `[data-stage="${k}"]`),
  );
  const cv = {
    analog: must<HTMLCanvasElement>(root, 'canvas[data-cv="analog"]'),
    adc: must<HTMLCanvasElement>(root, 'canvas[data-cv="adc"]'),
    lens: must<HTMLCanvasElement>(root, 'canvas[data-cv="lens"]'),
    mcu: must<HTMLCanvasElement>(root, 'canvas[data-cv="mcu"]'),
    phasor: must<HTMLCanvasElement>(root, 'canvas[data-cv="phasor"]'),
    spectrum: must<HTMLCanvasElement>(root, 'canvas[data-cv="spectrum"]'),
  };
  const carriesEls = new Map<string, HTMLElement>();
  root.querySelectorAll<HTMLElement>('[data-carries]').forEach((el) => {
    const key = el.dataset['carries'];
    if (key) carriesEls.set(key, el);
  });
  const cells = new Map<string, HTMLElement>();
  root.querySelectorAll<HTMLElement>('[data-out]').forEach((el) => {
    const key = el.dataset['out'];
    if (key) cells.set(key, el);
  });
  const put = (key: string, text: string): void => {
    const el = cells.get(key);
    if (el) el.textContent = text;
  };

  const css = getComputedStyle(root);
  const color = (name: string): string => css.getPropertyValue(name).trim();
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ---- état ----
  const worker = new Worker(new URL('./bench.worker.ts', import.meta.url), { type: 'module' });
  let seq = 0;
  let sent: AcquireRequest | null = null;
  let req: AcquireRequest | null = null;
  let res: AcquireResult | null = null;
  let inflight = false;
  let again = false;
  let announceNext = false;
  let waiting = false;
  let playing = !reduced;
  let visible = true;
  /** Position dans le cycle : 0 = début, 1 = tout est affiché. */
  let p = playing ? 0 : 1;
  let raf = 0;
  let prev = 0;
  const lastS = [-1, -1, -1, -1];
  let nodeY: number[] = [];

  function readRequest(): AcquireRequest {
    const bits = root.querySelector<HTMLInputElement>('input[name="bits"]:checked');
    const sampling = root.querySelector<HTMLInputElement>('input[name="sampling"]:checked');
    return {
      id: ++seq,
      dut: toDut(dutSel.value),
      freq: sliderToFreq(Number(freqEl.value)),
      snrDb: Number(snrEl.value),
      bits: Number(bits?.value ?? 16),
      multiplexed: sampling?.value === 'mux',
      seed: (Math.random() * 4294967296) >>> 0,
    };
  }

  function request(announce = false): void {
    if (announce) announceNext = true;
    if (inflight) {
      again = true;
      return;
    }
    inflight = true;
    sent = readRequest();
    worker.postMessage(sent);
  }

  worker.onmessage = (event: MessageEvent<AcquireResult>) => {
    inflight = false;
    if (sent) accept(sent, event.data);
    if (again) {
      again = false;
      request();
    }
  };

  // ---- résultats : tableau et textes du fil rouge ----
  function accept(r: AcquireRequest, a: AcquireResult): void {
    req = r;
    res = a;
    if (waiting) {
      waiting = false;
      p = 0;
    }
    fillTable(r, a);
    fillCarries(r, a);
    lastS.fill(-1);
    paint();
  }

  function fillTable(r: AcquireRequest, a: AcquireResult): void {
    const omega = TAU * a.freq;
    const meas = derive(r.dut, omega, a.zRe, a.zIm);
    const truth = derive(r.dut, omega, a.trueRe, a.trueIm);
    const magM = Math.hypot(a.zRe, a.zIm);
    const magT = Math.hypot(a.trueRe, a.trueIm);
    const phM = deg(Math.atan2(a.zIm, a.zRe));
    const phT = deg(Math.atan2(a.trueIm, a.trueRe));
    const unit = unitOf(r.dut);

    put('freq', eng(a.freq, 'Hz'));
    put('mag-meas', eng(magM, 'Ω'));
    put('mag-true', eng(magT, 'Ω'));
    put('mag-err', signed((magM / magT - 1) * 100, 3, ' %'));
    put('phase-meas', `${num(phM, 5)} °`);
    put('phase-true', `${num(phT, 5)} °`);
    put('phase-err', signed(phM - phT, 3, ' °'));
    put('val-label', labels.value[r.dut]);
    put('val-meas', eng(meas.val, unit));
    put('val-true', eng(truth.val, unit));
    put('val-err', signed((meas.val / truth.val - 1) * 100, 3, ' %'));
    rsRow.hidden = r.dut === 'R';
    if (r.dut !== 'R') {
      put('rs-label', labels.rs[r.dut]);
      put('rs-meas', eng(meas.rs, 'Ω'));
      put('rs-true', eng(truth.rs, 'Ω'));
      put('rs-err', signed(meas.rs - truth.rs, 3, ' Ω'));
    }
    put('rep', `σ|Z| ${num(a.sigmaMag * 100, 3)} %  ·  σθ ${num(a.sigmaPhase, 3)} °`);

    if (announceNext) {
      announceNext = false;
      srEl.textContent = `${labels.dut[r.dut]}, ${eng(a.freq, 'Hz')}: ${labels.impedance} = ${eng(magM, 'Ω')}, ${labels.phase} = ${num(phM, 4)} °`;
    }
  }

  function fillCarries(r: AcquireRequest, a: AcquireResult): void {
    const lsb = 2 / 2 ** r.bits;
    const thetaMeas = deg(Math.atan2(a.zIm, a.zRe));
    const dt = Math.abs(a.theta) / (TAU * a.freq);
    const set = (key: string, text: string): void => {
      const el = carriesEls.get(key);
      if (el) el.textContent = text;
    };
    set('analog', fmt(labels.carries.analog, { dt: eng(dt, 's', 3), theta: num(deg(a.theta), 4) }));
    set(
      'adc',
      fmt(r.multiplexed ? labels.carries.adcMux : labels.carries.adc, {
        lsb: eng(lsb, 'FS', 3),
        bits: String(r.bits),
        snr: String(r.snrDb),
        skew: eng(a.skew, 's', 2),
        skewdeg: num(Math.abs(360 * a.freq * a.skew), 3),
      }),
    );
    set('mcu', fmt(labels.carries.mcu, { n: String(N), k: String(a.bin) }));
    set(
      'dsp',
      fmt(labels.carries.dsp, {
        phiV: num(deg(Math.atan2(a.vIm, a.vRe)), 4),
        phiI: num(deg(Math.atan2(a.iIm, a.iRe)), 4),
        theta: num(thetaMeas, 4),
      }),
    );
    set('result', fmt(labels.carries.result, { z: eng(Math.hypot(a.zRe, a.zIm), 'Ω'), theta: num(thetaMeas, 4) }));
  }

  // ---- dessin ----
  function prep(canvas: HTMLCanvasElement): { ctx: CanvasRenderingContext2D; w: number; h: number } | null {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    if (w === 0 || h === 0) return null;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    }
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    ctx.font = `11px ${color('--mono') || 'monospace'}`;
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'left';
    ctx.lineJoin = 'round';
    return { ctx, w, h };
  }

  function grid(ctx: CanvasRenderingContext2D, w: number, h: number, cols: number, rows: number): void {
    ctx.save();
    ctx.strokeStyle = color('--line');
    ctx.lineWidth = 1;
    ctx.globalAlpha = 0.55;
    ctx.beginPath();
    for (let i = 1; i < cols; i++) {
      const x = Math.round((i * w) / cols) + 0.5;
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
    }
    for (let j = 1; j < rows; j++) {
      const y = Math.round((j * h) / rows) + 0.5;
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
    }
    ctx.stroke();
    ctx.restore();
  }

  function dashed(ctx: CanvasRenderingContext2D, x: number, y0: number, y1: number, stroke: string): void {
    ctx.save();
    ctx.strokeStyle = stroke;
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(Math.round(x) + 0.5, y0);
    ctx.lineTo(Math.round(x) + 0.5, y1);
    ctx.stroke();
    ctx.restore();
  }

  function arrow(ctx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number, stroke: string): void {
    ctx.save();
    ctx.strokeStyle = stroke;
    ctx.fillStyle = stroke;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1, y1);
    ctx.stroke();
    const a = Math.atan2(y1 - y0, x1 - x0);
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x1 - 9 * Math.cos(a - 0.4), y1 - 9 * Math.sin(a - 0.4));
    ctx.lineTo(x1 - 9 * Math.cos(a + 0.4), y1 - 9 * Math.sin(a + 0.4));
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  /** Étage 1 : sinusoïdes analogiques de V et I ; le décalage temporel entre leurs passages à zéro. */
  const paintAnalog: Painter = (s) => {
    const c = prep(cv.analog);
    if (!c) return;
    const { ctx, w, h } = c;
    grid(ctx, w, h, 9, 4);
    ctx.fillStyle = color('--cyan');
    ctx.fillText('V', 10, 12);
    ctx.fillStyle = color('--magenta');
    ctx.fillText('I', 26, 12);
    if (!res || s <= 0) return;

    const omega = TAU * res.freq;
    const span = 3 / res.freq;
    const y = (a: number): number => h / 2 - (a / AMP) * 0.78 * (h / 2);
    const steps = Math.max(8, Math.round(w / 2));
    const last = Math.round(steps * s);
    const curve = (shift: number, stroke: string): void => {
      ctx.beginPath();
      for (let q = 0; q <= last; q++) {
        const t = (q / steps) * span;
        const py = y(AMP * Math.sin(omega * t + res!.phi0 - shift));
        if (q === 0) ctx.moveTo(0, py);
        else ctx.lineTo((q / steps) * w, py);
      }
      ctx.strokeStyle = stroke;
      ctx.lineWidth = 1.8;
      ctx.stroke();
    };
    curve(0, color('--cyan'));
    curve(res.theta, color('--magenta'));

    if (s < 1) dashed(ctx, (last / steps) * w, 0, h, color('--ink-2'));

    // Décalage Δt entre les deux passages à zéro montants, pris dans la deuxième période.
    const alpha = clamp01((s - 0.55) / 0.25);
    if (alpha > 0) {
      const m = Math.ceil((omega * (span / 3) + res.phi0) / TAU);
      const tV = (TAU * m - res.phi0) / omega;
      const tI = tV + res.theta / omega;
      const xV = (tV / span) * w;
      const xI = (tI / span) * w;
      ctx.save();
      ctx.globalAlpha = alpha;
      dashed(ctx, xV, 0, h - 8, color('--cyan'));
      dashed(ctx, xI, 0, h - 8, color('--magenta'));
      const yb = h - 16;
      const gap = Math.abs(xV - xI);
      ctx.fillStyle = color('--ink');
      if (gap > 3) {
        ctx.strokeStyle = color('--ink');
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(Math.min(xV, xI), yb);
        ctx.lineTo(Math.max(xV, xI), yb);
        ctx.moveTo(Math.min(xV, xI), yb - 4);
        ctx.lineTo(Math.min(xV, xI), yb + 4);
        ctx.moveTo(Math.max(xV, xI), yb - 4);
        ctx.lineTo(Math.max(xV, xI), yb + 4);
        ctx.stroke();
      }
      ctx.textAlign = 'left';
      ctx.fillText('Δt', Math.max(xV, xI) + 6, yb - 8);
      ctx.restore();
    }
  };

  /** Étage 2, graphique principal : échantillons de V et I, et instants d'échantillonnage. */
  const paintAdc: Painter = (s) => {
    const c = prep(cv.adc);
    if (!c) return;
    const { ctx, w, h } = c;
    const hp = h - 40;
    grid(ctx, w, hp, 9, 4);
    ctx.fillStyle = color('--cyan');
    ctx.fillText('V', 10, 12);
    ctx.fillStyle = color('--magenta');
    ctx.fillText('I', 26, 12);
    if (!res || !req || s <= 0) return;

    const count = Math.min(N, Math.round((3 * N) / res.bin));
    const y = (a: number): number => hp / 2 - (a / AMP) * 0.78 * (hp / 2);
    const omega = TAU * res.freq;

    // Signal analogique de référence, en filigrane.
    ctx.save();
    ctx.globalAlpha = 0.3;
    ctx.lineWidth = 1;
    for (const [shift, stroke] of [
      [0, color('--cyan')],
      [res.theta, color('--magenta')],
    ] as const) {
      ctx.beginPath();
      const steps = Math.max(8, Math.round(w / 2));
      for (let q = 0; q <= steps; q++) {
        const t = ((q / steps) * count) / FS;
        const py = y(AMP * Math.sin(omega * t + res.phi0 - shift));
        if (q === 0) ctx.moveTo(0, py);
        else ctx.lineTo((q / steps) * w, py);
      }
      ctx.strokeStyle = stroke;
      ctx.stroke();
    }
    ctx.restore();

    // Échantillons (au plus ~90 points dessinés).
    const stride = Math.max(1, Math.ceil(count / 90));
    const lastN = Math.floor(count * s);
    const skewN = res.skew * FS;
    for (let n = 0; n < lastN; n += stride) {
      ctx.fillStyle = color('--cyan');
      ctx.beginPath();
      ctx.arc(((n + 0.5) / count) * w, y(res.v[n]), 1.9, 0, TAU);
      ctx.fill();
      ctx.fillStyle = color('--magenta');
      ctx.beginPath();
      ctx.arc(((n + 0.5 + skewN) / count) * w, y(res.i[n]), 1.9, 0, TAU);
      ctx.fill();
    }
    if (s < 1) dashed(ctx, (lastN / count) * w, 0, hp, color('--ink-2'));

    // Instants d'échantillonnage de chaque voie : alignés, ou décalés d'une demi-période avec un seul CAN.
    const a = clamp01((s - 0.35) / 0.3);
    ctx.save();
    ctx.globalAlpha = a;
    const x0 = 26;
    const step = (w - x0 - 12) / 8.6;
    const rows: ReadonlyArray<readonly [string, number, string, number]> = [
      ['V', hp + 14, color('--cyan'), 0],
      ['I', hp + 30, color('--magenta'), res.skew * FS],
    ];
    for (const [name, yy, stroke, off] of rows) {
      ctx.fillStyle = stroke;
      ctx.fillText(name, 10, yy);
      ctx.strokeStyle = stroke;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let i = 0; i < 9; i++) {
        const x = x0 + (i + off) * step;
        ctx.moveTo(x, yy - 5);
        ctx.lineTo(x, yy + 5);
      }
      ctx.stroke();
    }
    ctx.fillStyle = color('--ink-2');
    ctx.textAlign = 'right';
    ctx.fillText(`Ts = ${eng(1 / FS, 's', 2)}`, w - 8, hp + 4);
    ctx.restore();
  };

  /** Étage 2, zoom : écart de chaque échantillon de V au signal idéal, en pas de CAN (LSB). */
  const paintLens: Painter = (s) => {
    const c = prep(cv.lens);
    if (!c) return;
    const { ctx, w, h } = c;
    if (!res || !req || s <= 0) {
      grid(ctx, w, h, 8, 4);
      return;
    }
    const lsb = 2 / 2 ** req.bits;
    const M = 64;
    const omega = TAU * res.freq;
    const err: number[] = [];
    let maxAbs = 0;
    for (let n = 0; n < M; n++) {
      const e = (res.v[n] - AMP * Math.sin((omega * n) / FS + res.phi0)) / lsb;
      err.push(e);
      maxAbs = Math.max(maxAbs, Math.abs(e));
    }
    const target = Math.max(1, maxAbs * 1.1);
    let range = 1;
    for (const r of [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000]) {
      range = r;
      if (r >= target) break;
    }
    const mid = h / 2;
    const k = (mid - 12) / range;
    grid(ctx, w, h, 8, 4);
    ctx.fillStyle = color('--cyan');
    ctx.globalAlpha = 0.1;
    ctx.fillRect(0, mid - 0.5 * k, w, k);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = color('--ink-2');
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, Math.round(mid) + 0.5);
    ctx.lineTo(w, Math.round(mid) + 0.5);
    ctx.stroke();

    const last = Math.floor(M * s);
    ctx.strokeStyle = color('--cyan');
    ctx.fillStyle = color('--cyan');
    ctx.lineWidth = 1.5;
    for (let n = 0; n < last; n++) {
      const x = ((n + 0.5) / M) * w;
      const yy = mid - err[n] * k;
      ctx.beginPath();
      ctx.moveTo(x, mid);
      ctx.lineTo(x, yy);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(x, yy, 2, 0, TAU);
      ctx.fill();
    }
    ctx.fillStyle = color('--ink-2');
    ctx.fillText(`±${range} LSB`, 8, 10);
    ctx.textAlign = 'right';
    ctx.fillText(`1 LSB = ${eng(lsb, 'FS', 3)}`, w - 8, 10);
    ctx.textAlign = 'left';
  };

  /** Étage 3 : les deux tampons de N échantillons, comme une zone mémoire qui se remplit. */
  const paintMcu: Painter = (s) => {
    const c = prep(cv.mcu);
    if (!c) return;
    const { ctx, w, h } = c;
    const strip = 28;
    const top = 22;
    const gap = 22;
    ctx.fillStyle = color('--ink-2');
    ctx.fillText('V[n]', 0, 9);
    ctx.fillText('I[n]', 0, top + strip + gap - 11);
    if (!res) return;
    const M = Math.min(N, Math.round((4 * N) / res.bin));
    const filled = Math.floor(w * s);
    const rows: ReadonlyArray<readonly [Float32Array, string, number]> = [
      [res.v, color('--cyan'), top],
      [res.i, color('--magenta'), top + strip + gap],
    ];
    for (const [arr, pos, y0] of rows) {
      ctx.fillStyle = color('--scope');
      ctx.fillRect(0, y0, w, strip);
      for (let x = 0; x < filled; x++) {
        const a = arr[Math.min(M - 1, Math.floor((x / w) * M))] / AMP;
        ctx.globalAlpha = Math.min(1, Math.abs(a) * 0.95 + 0.04);
        ctx.fillStyle = a >= 0 ? pos : color('--violet');
        ctx.fillRect(x, y0, 1, strip);
      }
      ctx.globalAlpha = 1;
      ctx.strokeStyle = color('--line');
      ctx.strokeRect(0.5, y0 + 0.5, w - 1, strip - 1);
    }
    if (s > 0 && s < 1) dashed(ctx, filled, top - 4, top + 2 * strip + gap + 4, color('--ink'));

    // Fenêtre complète : la partie dessinée ci-dessus (~4 périodes) dans le tampon de N échantillons.
    const yb = h - 12;
    ctx.strokeStyle = color('--line');
    ctx.lineWidth = 1;
    ctx.strokeRect(0.5, yb - 4.5, w - 1, 9);
    ctx.fillStyle = color('--ink-2');
    ctx.globalAlpha = 0.5;
    ctx.fillRect(1, yb - 4, Math.max(2, (M / N) * (w - 2)), 8);
    ctx.globalAlpha = 1;
    ctx.fillStyle = color('--accent');
    ctx.fillRect(1, yb - 4, Math.max(0, s * (w - 2)), 2);
    ctx.fillStyle = color('--ink-2');
    ctx.textAlign = 'right';
    ctx.fillText(`n = ${Math.round(s * N)} / ${N}`, w, yb - 14);
    ctx.textAlign = 'left';
  };

  /** Étage 4a : les phaseurs V et I issus de la DFT, et l'angle entre eux. */
  const paintPhasor: Painter = (s) => {
    const c = prep(cv.phasor);
    if (!c) return;
    const { ctx, w, h } = c;
    const cx = w / 2;
    const cy = h / 2;
    const R = Math.min(w, h) / 2 - 16;
    ctx.strokeStyle = color('--line');
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx - R - 8, Math.round(cy) + 0.5);
    ctx.lineTo(cx + R + 8, Math.round(cy) + 0.5);
    ctx.moveTo(Math.round(cx) + 0.5, cy - R - 8);
    ctx.lineTo(Math.round(cx) + 0.5, cy + R + 8);
    ctx.stroke();
    ctx.globalAlpha = 0.6;
    ctx.beginPath();
    ctx.arc(cx, cy, R * 0.92, 0, TAU);
    ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.fillStyle = color('--ink-2');
    ctx.fillText('Re', cx + R - 6, cy - 9);
    ctx.fillText('Im', cx + 6, cy - R - 2);
    if (!res || s <= 0) return;

    const grow = clamp01(s * 1.5);
    const phiV = Math.atan2(res.vIm, res.vRe);
    const phiI = Math.atan2(res.iIm, res.iRe);
    const lenV = R * 0.92 * (Math.hypot(res.vRe, res.vIm) / AMP) * grow;
    const lenI = R * 0.92 * (Math.hypot(res.iRe, res.iIm) / AMP) * grow;
    const tip = (len: number, phi: number): [number, number] => [cx + len * Math.cos(phi), cy - len * Math.sin(phi)];

    const arcAlpha = clamp01((s - 0.6) / 0.3);
    if (arcAlpha > 0) {
      const th = wrap(phiV - phiI);
      ctx.save();
      ctx.globalAlpha = arcAlpha;
      ctx.strokeStyle = color('--ink');
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.42, -phiI, -phiV, th > 0);
      ctx.stroke();
      const mid = phiI + th / 2;
      ctx.fillStyle = color('--ink');
      ctx.textAlign = 'center';
      ctx.fillText('θ', cx + R * 0.6 * Math.cos(mid), cy - R * 0.6 * Math.sin(mid));
      ctx.restore();
    }
    const [ix, iy] = tip(lenI, phiI);
    const [vx, vy] = tip(lenV, phiV);
    arrow(ctx, cx, cy, ix, iy, color('--magenta'));
    arrow(ctx, cx, cy, vx, vy, color('--cyan'));
    ctx.textAlign = 'left';
    ctx.fillStyle = color('--magenta');
    ctx.fillText('I', ix + 6 * Math.cos(phiI) + 3, iy - 6 * Math.sin(phiI));
    ctx.fillStyle = color('--cyan');
    ctx.fillText('V', vx + 6 * Math.cos(phiV) + 3, vy - 6 * Math.sin(phiV));
  };

  /** Étage 4b : spectre de V ; la DFT lit le bin de la fréquence d'excitation. */
  const paintSpectrum: Painter = (s) => {
    const c = prep(cv.spectrum);
    if (!c) return;
    const { ctx, w, h } = c;
    grid(ctx, w, h, 10, 6);
    ctx.fillStyle = color('--ink-2');
    ctx.fillText('0 dBFS', 8, 10);
    ctx.textAlign = 'right';
    ctx.fillText(`${eng(FS / 2, 'Hz', 3)}  |  ${MINUS}140 dBFS`, w - 8, 10);
    ctx.textAlign = 'left';
    if (!res || s <= 0) return;

    const bins = res.spectrum.length;
    const upTo = Math.max(2, Math.floor(bins * s));
    const px = (b: number): number => (b / (bins - 1)) * w;
    const py = (db: number): number => Math.min(Math.max(-db / 140, 0), 1) * (h - 2) + 1;
    ctx.beginPath();
    ctx.moveTo(px(1), h);
    for (let b = 1; b < upTo; b++) ctx.lineTo(px(b), py(res.spectrum[b]));
    ctx.lineTo(px(upTo - 1), h);
    ctx.closePath();
    ctx.fillStyle = color('--cyan');
    ctx.globalAlpha = 0.16;
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.beginPath();
    for (let b = 1; b < upTo; b++) {
      if (b === 1) ctx.moveTo(px(b), py(res.spectrum[b]));
      else ctx.lineTo(px(b), py(res.spectrum[b]));
    }
    ctx.strokeStyle = color('--cyan');
    ctx.lineWidth = 1;
    ctx.stroke();
    if (upTo > res.bin) {
      const mx = px(res.bin);
      const my = py(res.spectrum[res.bin]);
      dashed(ctx, mx, my, h, color('--magenta'));
      ctx.fillStyle = color('--magenta');
      ctx.beginPath();
      ctx.arc(mx, my, 3.5, 0, TAU);
      ctx.fill();
      ctx.fillStyle = color('--ink');
      ctx.fillText(`k = ${res.bin}`, Math.min(mx + 8, w - 52), Math.max(my, 24));
    }
  };

  const painters: readonly Painter[] = [
    (s) => paintAnalog(s),
    (s) => {
      paintAdc(s);
      paintLens(s);
    },
    (s) => paintMcu(s),
    (s) => {
      paintPhasor(s);
      paintSpectrum(s);
    },
  ];

  // ---- impulsion et états des étages ----
  function position(): { i: number; s: number; travel: number } {
    if (p >= 1) return { i: 4, s: 1, travel: 0 };
    const u = p * 5;
    const i = Math.floor(u);
    const f = u - i;
    if (i >= 4) return { i, s: 1, travel: 0 };
    if (f < DWELL) return { i, s: f / DWELL, travel: 0 };
    return { i, s: 1, travel: (f - DWELL) / (1 - DWELL) };
  }

  function measureNodes(): void {
    const top = chain.getBoundingClientRect();
    nodeY = stageEls.map((el) => {
      const r = must<HTMLElement>(el, '[data-node]').getBoundingClientRect();
      return r.top - top.top + r.height / 2;
    });
    const first = must<HTMLElement>(stageEls[0], '[data-node]').getBoundingClientRect();
    pulse.style.left = `${first.left - top.left + first.width / 2}px`;
  }

  function paint(): void {
    const { i, s, travel } = position();
    for (let j = 0; j < 4; j++) {
      const sj = j < i ? 1 : j > i ? 0 : s;
      if (sj !== lastS[j]) {
        lastS[j] = sj;
        painters[j](sj);
      }
    }
    stageEls.forEach((el, j) => {
      const state = !playing && p >= 1 ? 'done' : j < i ? 'done' : j === i ? 'active' : 'todo';
      if (el.dataset['state'] !== state) el.dataset['state'] = state;
    });
    pulse.hidden = !playing;
    if (playing && nodeY.length === 5) {
      const y = i < 4 ? nodeY[i] + (nodeY[i + 1] - nodeY[i]) * travel : nodeY[4];
      pulse.style.transform = `translate3d(-50%, ${y - 6}px, 0)`;
    }
  }

  function tick(now: number): void {
    raf = requestAnimationFrame(tick);
    const dt = Math.min(now - prev, 80);
    prev = now;
    if (waiting) return;
    p += dt / CYCLE_MS;
    if (p >= 1) {
      p = 1;
      waiting = true;
      request();
    }
    paint();
  }

  function sync(): void {
    const should = playing && visible && !document.hidden;
    if (should && raf === 0) {
      prev = performance.now();
      raf = requestAnimationFrame(tick);
    } else if (!should && raf !== 0) {
      cancelAnimationFrame(raf);
      raf = 0;
    }
  }

  function setPlaying(on: boolean): void {
    playing = on;
    playBtn.textContent = on ? labels.pause : labels.play;
    playBtn.setAttribute('aria-pressed', String(on));
    if (!on) {
      waiting = false;
      p = 1;
    }
    lastS.fill(-1);
    measureNodes();
    paint();
    sync();
  }

  // ---- événements ----
  playBtn.addEventListener('click', () => {
    if (playing) {
      setPlaying(false);
    } else {
      p = 0;
      setPlaying(true);
      request();
    }
  });
  replayBtn.addEventListener('click', () => {
    p = 0;
    waiting = false;
    setPlaying(true);
    request();
  });
  root.addEventListener('input', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLInputElement || target instanceof HTMLSelectElement)) return;
    const wasWaiting = waiting;
    request(true);
    if (!playing) p = 1;
    waiting = wasWaiting;
  });

  const redraw = (): void => {
    measureNodes();
    lastS.fill(-1);
    paint();
  };
  const ro = new ResizeObserver(redraw);
  ro.observe(chain);
  Object.values(cv).forEach((el) => ro.observe(el));
  new IntersectionObserver((entries) => {
    visible = entries.some((e) => e.isIntersecting);
    sync();
  }).observe(root);
  document.addEventListener('visibilitychange', sync);

  const updateOutputs = (): void => {
    put('freq', eng(sliderToFreq(Number(freqEl.value)), 'Hz'));
    put('snr', `${snrEl.value} dB`);
  };
  root.addEventListener('input', updateOutputs);

  playBtn.textContent = playing ? labels.pause : labels.play;
  playBtn.setAttribute('aria-pressed', String(playing));
  updateOutputs();
  measureNodes();
  request();
  sync();
}
